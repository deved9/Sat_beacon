function [data_tx] = gen_harmonic(f,fs,N)
f_step=fs/N;
if (mod(f, f_step)~=0)
    warning('The required frequency does not fall into the frequency step. The result is not pure. F_step is %f', f_step);
end

t=(0:N-1)/fs;

data_tx=exp(1i*2*pi*f.*t);

end

