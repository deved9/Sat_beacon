clc
clear all
close all

addpath rfsoc_matlab

ip='192.168.0.3'; % ip adresa RFSoCu
session=open_rfsoc(ip); % open session

%% spusteni vysilani
tx_power_dB1=-0; % -10 dBFS
tx_power_dB2=-15; % -15 dBFS

fs=4096/8;

N_tx=1024; % pocet vzorku
f1=-30; % MHz
f2=20; % MHz
data_tx=10^(tx_power_dB1/20) * gen_harmonic(f1, fs, N_tx);% + 10^(tx_power_dB2/20) * gen_harmonic(f2, fs, N_tx);
write_data(session, data_tx); % send data to DAC buffer


%%
N=65536*8;
data_rx=read_data(session, N); % read data to ADC buffer; N vzorku

X=(0:N-1).'-N/2; % x-scale in samples from -N/2 to N/2-1
X=X/N*fs;

plot(X, 20*log10(abs(fftshift(fft(data_rx)))));

%%
close_rfsoc(session); % close session
clear session;